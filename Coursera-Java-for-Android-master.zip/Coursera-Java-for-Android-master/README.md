# Coursera-Java-for-Android
### [Solutions for the course Java for Android](https://www.coursera.org/learn/java-for-android/)
#### Please do star the repository if you are using it for getting help in the course . Fork the project and collaborate to improve the solutions . PRs are welcome.

##### Week 1
[Solutions](https://github.com/TheAlgo/Coursera-Java-for-Android/tree/master/Week%201)

##### Week 2
[Solutions](https://github.com/TheAlgo/Coursera-Java-for-Android/tree/master/Week%202)

##### Week 3
[Solutions](https://github.com/TheAlgo/Coursera-Java-for-Android/tree/master/Week%203)
